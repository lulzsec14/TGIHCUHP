# simple-video-chat
Simple Video Chat is a simple video chat application in which participants can join rooms and communicate using video and audio

## Blog Post 
Check out this detailed blog post explaining how one can set up their own video chat application with Web Sockets.
https://rishibolinjkar.hashnode.dev/how-to-build-a-simple-video-chat-application-using-react-js
